#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    pNameDialog = new PlayerNameDialog();
    pNameDialog->enterNames();

    string *tempNames = pNameDialog->getNames();
    names[0] = tempNames[0];
    names[1] = tempNames[1];

    pNameDialog->setModal(true);
    pNameDialog->exec();
    initBoard(this);
    qDebug() << "NAME 1: " << names[0];
    qDebug() << "NAME 2: " << names[1];
    qDebug() << "NAME 1: " << names[0];
    qDebug() << "NAME 2: " << names[1];

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(checkersBoardLayout);
    setCentralWidget(centralWidget);

    const int boardSize = 8 * tileSize;
    resize(boardSize, boardSize);
}

MainWindow::~MainWindow()
{
    delete ui;
}

QPixmap createCirclePixmap(QColor color)
{
    QPixmap pixmap(30, 30);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing);

    painter.setPen(Qt::NoPen);
    painter.setBrush(color);

    QRectF rectangle(5.0, 5.0, 20.0, 20.0);
    painter.drawEllipse(rectangle);

    return pixmap;
}

void MainWindow::initBoard(QWidget *parentWidget)
{
    checkersBoardLayout = new QGridLayout(parentWidget);
    checkersBoardLayout->setSpacing(0);

    const QStringList tileColors = QStringList() << "red"
                                                 << "black";
    int colorIndex = 0;

    for (int row = 1; row <= 8; row++)
    {
        for (int col = 1; col <= 8; col++)
        {
            QWidget *tile = new QWidget(parentWidget);
            tile->setFixedSize(tileSize, tileSize);
            tile->setStyleSheet("background-color: " + tileColors[colorIndex] + ";");

            QPixmap circlePixmap;
            if ((row < 3 && colorIndex == 1) || (row > 6 && colorIndex == 0))
            {
                circlePixmap = createCirclePixmap(Qt::black);
            }
            else if ((row < 3 && colorIndex == 0) || (row > 6 && colorIndex == 1))
            {
                circlePixmap = createCirclePixmap(Qt::white);
            }
            QLabel *circleLabel = new QLabel(tile);
            circleLabel->setPixmap(circlePixmap);
            circleLabel->setAlignment(Qt::AlignCenter);

            checkersBoardLayout->addWidget(tile, row, col);
            checkersBoardLayout->addWidget(circleLabel, row, col, Qt::AlignCenter);
            colorIndex = (colorIndex + 1) % 2;
        }
        colorIndex = (colorIndex + 1) % 2;
    }

    // Create and add the QLabel to the layout
    QLabel *turnLabel = new QLabel(QString::fromStdString(names[0]) + "'s turn", parentWidget);
    turnLabel->setAlignment(Qt::AlignCenter);
    checkersBoardLayout->addWidget(turnLabel, 9, 1, 1, 8);

    // parentWidget->setLayout(checkersBoardLayout);
}

// git log
// git cherry-pick <commit-id>
